# Third-party dependencies

`sunxi-mpp-sdk/` is generated locally and intentionally ignored by Git.  Create
it with:

```sh
./tools/fetch_sunxi_mpp.sh
```

The fetcher pins Yuzukilizard commit
`94bb93ad67fd862c5f6fe6c29fbc0f54950e7107`, copies the MPP headers, and copies
only the libraries listed in `sunxi-mpp.manifest`.  The generated bundle is the
default value of `SUNXI_MPP_ROOT` used by Application's CMake build.

When the workspace reference tree is already prepared at the pinned commit,
the fetcher can reuse it without network access:

```sh
SUNXI_MPP_SOURCE_CHECKOUT="$PWD/../TMP/Yuzukilizard" \
  ./tools/fetch_sunxi_mpp.sh
```

The current manifest includes the video-only DEMUX/VDEC archives required by
`PlaybackPipeline`. `audit_sunxi_mpp.sh` derives every `AW_MPI_*` call used by
the product service and checks that the selected static archives define it.
This is a symbol-presence check, not a successful-link or board capability
claim.

The upstream `Software/sunxi-mpp` directory is a convenience binary SDK, not a
self-contained source release.  Its libraries are prebuilt for 32-bit ARM,
musl and the hard-float ABI.  The upstream repository does not provide a
software license covering this directory, and the optional Vivante VIPLite
headers identify themselves as proprietary.  Keep the generated bundle local
until redistribution rights have been confirmed with the relevant owners.

Using this bundle removes the *build-time TinaSDK dependency* from the MPP
components.  It does not remove the target's kernel-driver, device-tree,
firmware, ISP tuning, C library or ABI requirements.
