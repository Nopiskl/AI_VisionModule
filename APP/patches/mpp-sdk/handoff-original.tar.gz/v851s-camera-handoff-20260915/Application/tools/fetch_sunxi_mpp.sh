#!/usr/bin/env bash

set -euo pipefail

readonly UPSTREAM_URL="https://github.com/ohdarling/Yuzukilizard.git"
readonly UPSTREAM_COMMIT="94bb93ad67fd862c5f6fe6c29fbc0f54950e7107"

script_dir="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
application_dir="$(CDPATH= cd -- "${script_dir}/.." && pwd)"
manifest="${application_dir}/third_party/sunxi-mpp.manifest"
destination="${SUNXI_MPP_DESTINATION:-${application_dir}/third_party/sunxi-mpp-sdk}"

if [[ -e "${destination}" ]]; then
    printf 'Destination already exists: %s\n' "${destination}" >&2
    printf 'Remove or relocate that exact directory before fetching again.\n' >&2
    exit 1
fi

if [[ ! -f "${manifest}" ]]; then
    printf 'Manifest not found: %s\n' "${manifest}" >&2
    exit 1
fi

work_dir="$(mktemp -d /tmp/v851s-sunxi-mpp-fetch.XXXXXX)"
checkout_dir="${work_dir}/Yuzukilizard"
stage_dir="${work_dir}/sunxi-mpp-sdk"

cleanup() {
    rm -rf -- "${work_dir}"
}
trap cleanup EXIT

if [[ -n "${SUNXI_MPP_SOURCE_CHECKOUT:-}" ]]; then
    checkout_dir="$(CDPATH= cd -- "${SUNXI_MPP_SOURCE_CHECKOUT}" && pwd)"
    actual_commit="$(git -C "${checkout_dir}" rev-parse HEAD)"
    if [[ "${actual_commit}" != "${UPSTREAM_COMMIT}" ]]; then
        printf 'Reference checkout is not at the pinned commit: %s\n' \
            "${actual_commit}" >&2
        exit 1
    fi
else
    git clone --filter=blob:none --no-checkout "${UPSTREAM_URL}" "${checkout_dir}"
    git -C "${checkout_dir}" sparse-checkout init --cone
    git -C "${checkout_dir}" sparse-checkout set \
        Software/sunxi-mpp \
        Software/BSP/openwrt/package/npu/viplite-driver/include
    git -C "${checkout_dir}" checkout --detach "${UPSTREAM_COMMIT}"
fi

source_root="${checkout_dir}/Software/sunxi-mpp"
mkdir -p "${stage_dir}/include" "${stage_dir}/lib"
cp -a "${source_root}/include/." "${stage_dir}/include/"

while read -r group relative_path extra; do
    if [[ -z "${group:-}" || "${group}" == \#* ]]; then
        continue
    fi
    if [[ -n "${extra:-}" ]]; then
        printf 'Malformed manifest line: %s %s %s\n' \
            "${group}" "${relative_path}" "${extra}" >&2
        exit 1
    fi
    source_file="${source_root}/${relative_path}"
    if [[ ! -e "${source_file}" && ! -L "${source_file}" ]]; then
        printf 'Upstream file is missing: %s\n' "${relative_path}" >&2
        exit 1
    fi
    mkdir -p "${stage_dir}/$(dirname -- "${relative_path}")"
    cp -a "${source_file}" "${stage_dir}/${relative_path}"
done < "${manifest}"

# The standalone sunxi-mpp tree ships NPU libraries but omits their public API.
# Keep these headers in the ignored local bundle; see third_party/README.md for
# the upstream proprietary notice and redistribution caveat.
viplite_headers="${checkout_dir}/Software/BSP/openwrt/package/npu/viplite-driver/include"
mkdir -p "${stage_dir}/include/viplite"
cp -a "${viplite_headers}/vip_lite.h" "${stage_dir}/include/viplite/"
cp -a "${viplite_headers}/vip_lite_common.h" "${stage_dir}/include/viplite/"

# libasound has SONAME libasound.so.2 but upstream only provides libasound.so.
ln -s libasound.so "${stage_dir}/lib/libasound.so.2"

printf '%s\n' "${UPSTREAM_URL}" > "${stage_dir}/UPSTREAM_URL"
printf '%s\n' "${UPSTREAM_COMMIT}" > "${stage_dir}/UPSTREAM_COMMIT"
(
    cd "${stage_dir}"
    find include lib -type f -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
)

mkdir -p "$(dirname -- "${destination}")"
mv "${stage_dir}" "${destination}"

printf 'Prepared standalone sunxi-mpp bundle at:\n  %s\n' "${destination}"
printf 'Pinned upstream commit:\n  %s\n' "${UPSTREAM_COMMIT}"
