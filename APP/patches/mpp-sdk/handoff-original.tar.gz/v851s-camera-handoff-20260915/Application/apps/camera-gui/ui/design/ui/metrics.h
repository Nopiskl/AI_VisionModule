#pragma once

#include <QtGlobal>

namespace Ui::Metrics
{
// 页面使用设计坐标，Dashboard 统一等比缩放到实际窗口尺寸。
inline constexpr int DefaultWidth = 800;
inline constexpr int DefaultHeight = 480;
inline constexpr qreal DesignWidth = 1600;
inline constexpr qreal DesignHeight = 960;
inline constexpr qreal HeaderHeight = 98;
inline constexpr qreal NavigationHeight = 78;
inline constexpr qreal NavigationDragHeight = 71;
} // namespace Ui::Metrics
