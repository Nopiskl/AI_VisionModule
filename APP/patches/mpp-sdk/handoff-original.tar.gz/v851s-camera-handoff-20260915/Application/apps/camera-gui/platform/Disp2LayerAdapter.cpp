#include "platform/Disp2LayerAdapter.hpp"

#include <QByteArray>
#include <QFile>
#include <QTextStream>

#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include <utility>

namespace camera {
namespace gui {
namespace {

// UAPI constants from the sunxi DISP2 framebuffer interface. Both ioctls take
// an unsigned-int pointer and return the layer handle associated with the
// framebuffer on display output 0 or 1.
constexpr unsigned long kFbGetLayerHandle0 = 0x4700;
constexpr unsigned long kFbGetLayerHandle1 = 0x4701;

bool parseInteger(const QString& text, int* value) {
    bool ok = false;
    const int parsed = text.trimmed().toInt(&ok, 10);
    if (ok) {
        *value = parsed;
    }
    return ok;
}

DisplayLayerContract failure(QString detail, int videoLayer = -1,
                             int configuredUiLayer = -1) {
    DisplayLayerContract result;
    result.videoLayer = videoLayer;
    result.configuredUiLayer = configuredUiLayer;
    result.detail = std::move(detail);
    return result;
}

}  // namespace

DisplayLayerContract Disp2LayerAdapter::validate(const QString& serviceConfig,
                                                 const QString& framebuffer,
                                                 const QString& backendLock,
                                                 int displayOutput) {
    QFile configFile(serviceConfig);
    if (!configFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return failure(QStringLiteral("无法读取 MPP 配置 %1：%2")
                           .arg(serviceConfig, configFile.errorString()));
    }

    int videoLayer = -1;
    int configuredUiLayer = -1;
    QString configuredBackendLock;
    QTextStream stream(&configFile);
    while (!stream.atEnd()) {
        QString line = stream.readLine();
        const int comment = line.indexOf(QLatin1Char('#'));
        if (comment >= 0) {
            line.truncate(comment);
        }
        const int separator = line.indexOf(QLatin1Char('='));
        if (separator < 0) {
            continue;
        }
        const QString key = line.left(separator).trimmed();
        const QString value = line.mid(separator + 1).trimmed();
        if (key == QStringLiteral("display.video_layer") &&
            !parseInteger(value, &videoLayer)) {
            return failure(QStringLiteral("display.video_layer 不是有效整数"));
        }
        if (key == QStringLiteral("display.ui_outside_layer") &&
            !parseInteger(value, &configuredUiLayer)) {
            return failure(
                QStringLiteral("display.ui_outside_layer 不是有效整数"),
                videoLayer);
        }
        if (key == QStringLiteral("ipc.backend_lock_path")) {
            configuredBackendLock = value;
        }
    }

    if (videoLayer < 0 || configuredUiLayer < 0) {
        return failure(
            QStringLiteral("MPP 配置缺少有效的 display.video_layer 或 "
                           "display.ui_outside_layer"),
            videoLayer, configuredUiLayer);
    }
    if (videoLayer == configuredUiLayer) {
        return failure(QStringLiteral("MPP video layer 与 Qt UI layer 配置重叠：%1")
                           .arg(videoLayer),
                       videoLayer, configuredUiLayer);
    }
    if (configuredBackendLock.isEmpty() ||
        configuredBackendLock != backendLock) {
        return failure(
            QStringLiteral("YOLO backend lock=%1，但 MPP 配置为 %2")
                .arg(backendLock,
                     configuredBackendLock.isEmpty()
                         ? QStringLiteral("<missing>")
                         : configuredBackendLock),
            videoLayer, configuredUiLayer);
    }
    if (displayOutput != 0 && displayOutput != 1) {
        return failure(QStringLiteral("DISP2 output 只接受 0 或 1"), videoLayer,
                       configuredUiLayer);
    }

    const QByteArray encoded = QFile::encodeName(framebuffer);
    const int descriptor =
        ::open(encoded.constData(), O_RDONLY | O_CLOEXEC);
    if (descriptor < 0) {
        return failure(QStringLiteral("无法打开 %1 查询 DISP2 layer：%2")
                           .arg(framebuffer,
                                QString::fromLocal8Bit(std::strerror(errno))),
                       videoLayer, configuredUiLayer);
    }

    unsigned int framebufferLayer = 0;
    const unsigned long command = displayOutput == 0 ? kFbGetLayerHandle0
                                                      : kFbGetLayerHandle1;
    const int ioctlResult = ::ioctl(descriptor, command, &framebufferLayer);
    const int ioctlError = errno;
    ::close(descriptor);
    if (ioctlResult != 0) {
        return failure(QStringLiteral("%1 不支持 DISP2 framebuffer layer 查询：%2")
                           .arg(framebuffer,
                                QString::fromLocal8Bit(std::strerror(ioctlError))),
                       videoLayer, configuredUiLayer);
    }

    DisplayLayerContract result;
    result.videoLayer = videoLayer;
    result.configuredUiLayer = configuredUiLayer;
    result.framebufferUiLayer = static_cast<int>(framebufferLayer);
    if (result.framebufferUiLayer != configuredUiLayer) {
        result.detail =
            QStringLiteral("linuxfb 实际 layer=%1，但 MPP outside layer 配置为 %2")
                .arg(result.framebufferUiLayer)
                .arg(configuredUiLayer);
        return result;
    }
    if (result.framebufferUiLayer == videoLayer) {
        result.detail = QStringLiteral("linuxfb 与 MPP video 使用了同一 layer=%1")
                            .arg(videoLayer);
        return result;
    }

    result.valid = true;
    result.detail = QStringLiteral("DISP2 layer 已隔离：MPP video=%1，Qt UI=%2")
                        .arg(videoLayer)
                        .arg(result.framebufferUiLayer);
    return result;
}

}  // namespace gui
}  // namespace camera
