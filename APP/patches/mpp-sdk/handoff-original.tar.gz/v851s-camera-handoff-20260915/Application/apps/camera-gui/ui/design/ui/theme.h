#pragma once

#include <QColor>
#include <QGradient>
#include <QString>

namespace Ui
{

struct PanelStyle {
    QColor top;
    QColor bottom;
    QColor border;
    qreal radius = 20;
};

// 所有颜色值集中在这里。按视觉用途命名，页面和绘制代码只引用样式。
namespace Theme
{
// Target images should ship Noto Sans CJK SC; Qt falls back to the platform
// default family when the font package is unavailable during host diagnostics.
inline const QString FontFamily = QStringLiteral("Noto Sans CJK SC");
inline const QColor TextPrimary("#f4f8ff");
inline const QColor TextMuted("#a9bedc");
inline const QColor TextDark("#071531");
inline const PanelStyle DefaultPanel{QColor("#14283f"), QColor("#0e1e30"), QColor("#294865")};

namespace Window
{
inline const QColor Canvas("#081525");
inline const QGradientStops Background{
    {0, QColor("#0d2139")}, {.5, QColor("#0a1728")}, {1, QColor("#06111f")}};
inline const QColor PreviewBorder("#496785");
} // namespace Window

namespace Control
{
inline const QColor FocusOutline("#66caff");
inline const QColor Feedback(100, 182, 255);
} // namespace Control

namespace Navigation
{
inline const QGradientStops Background{{0, QColor("#0d2139")}, {1, QColor("#081626")}};
inline const QColor Separator("#2b425d");
inline const PanelStyle SelectedTab{QColor("#133c74"), QColor("#075dcc"), QColor("#194579"), 17};
inline const QColor Underline("#25c9ff");
inline const QColor ActiveIcon("#55c7ff");
inline const QColor InactiveIcon("#8ba4c7");
} // namespace Navigation

namespace Home
{
inline const QGradientStops Header{
    {0, QColor("#123a70")}, {.35, QColor("#0e2546")}, {.67, QColor("#18375c")}, {1, QColor("#0c1c34")}};
inline const QColor HeaderShade(3, 15, 39, 65);
inline const QGradientStops Background{
    {0, QColor("#f2f9ff")}, {.5, QColor("#f4faff")}, {1, QColor("#e5f2ff")}};
inline const QColor LeftWave(103, 179, 252, 22);
inline const QColor RightWave(117, 192, 251, 24);
inline const QColor Subtitle("#546d93");
inline const PanelStyle Notice{QColor("#d8edff"), QColor("#d7eaff"), QColor("#d8edff"), 21};
inline const QColor NoticeIcon("#098bff");
inline const QColor NoticeDivider("#8eb5e6");
inline const QColor NoticeText("#41618d");
inline const PanelStyle Card{Qt::white, Qt::white, Qt::white, 25};
inline const QColor CardShadow(45, 65, 90);
inline const QColor CardPressedOutline("#219cff");
inline const QColor CardDescription("#4d648b");
inline const PanelStyle CameraAccent{QColor("#20acff"), QColor("#0066ff"), QColor(255, 255, 255, 80), 28};
inline const PanelStyle UvcAccent{QColor("#21c1c5"), QColor("#079796"), QColor(255, 255, 255, 80), 28};
inline const PanelStyle OpenCvAccent{QColor("#19c7b1"), QColor("#087f7a"), QColor(255, 255, 255, 80), 28};
} // namespace Home

namespace Overlay
{
inline const QColor Outline(220, 237, 255, 90);
inline const QColor Background(7, 18, 32);
inline const QColor Icon(220, 242, 255, 245);
inline const QColor SwitchOn(8, 125, 255, 220);
inline const QColor SwitchOff(202, 219, 236, 65);
inline const QColor SwitchKnob(255, 255, 255, 245);
inline const QColor CaptureOutline(245, 249, 255, 235);
inline const QColor CaptureInnerRing(255, 255, 255, 95);
inline const QGradientStops Record{{0, QColor(255, 85, 92, 225)}, {1, QColor(255, 41, 56, 205)}};
inline const QColor RecordIndicator("#ff3b30");
} // namespace Overlay

namespace Album
{
inline const PanelStyle Sidebar{QColor("#132947"), QColor("#09182c"), QColor("#2e517c"), 20};
inline const QColor LibraryIcon("#5cb9ff");
inline const PanelStyle Filters{QColor("#1b3557"), QColor("#152b49"), QColor("#42638f"), 22};
inline const PanelStyle SelectedFilter{QColor("#20b9ff"), QColor("#0670ff"), QColor("#439dff"), 20};
inline const PanelStyle Preview{Qt::black, Qt::black, QColor("#30465f"), 18};
inline const QColor EmptyText("#8899b0");
} // namespace Album

namespace Playback
{
inline const QGradientStops Play{{0, QColor("#24b8ff")}, {1, QColor("#0567ed")}};
inline const QGradientStops Step{{0, QColor("#1b304e")}, {1, QColor("#14243b")}};
inline const QColor PlayBorder("#6bd5ff");
inline const QColor StepBorder("#31557f");
inline const QColor DisabledIcon("#879ab6");
} // namespace Playback

namespace Uvc
{
inline const PanelStyle Content{QColor("#11222f"), QColor("#09141d"), QColor("#243b4d"), 25};
inline const PanelStyle UsbLabel{QColor("#263b49"), QColor("#162b39"), QColor("#2d4250"), 12};
inline const PanelStyle EnableButton{QColor("#155789"), QColor("#103c68"), QColor("#298bce"), 16};
inline const PanelStyle StopButton{QColor("#1d2933"), QColor("#15212b"), QColor("#3a4a57"), 16};
inline const QColor ConnectedLine("#2d97d8");
inline const QColor IdleLine("#455969");
inline const QColor EnabledIndicator("#31ca65");
inline const QColor IdleIndicator("#566d82");
inline const QColor EnabledText("#36d567");
inline const QColor IdleText("#a3b4c6");
inline const QColor Description("#a1b1c1");
inline const QColor StopOutline("#ff433e");
inline const QColor StopFill("#ff3d39");
} // namespace Uvc

namespace Brand
{
inline const QGradientStops LogoLeft{{0, QColor("#2ecef5")}, {.5, QColor("#008bff")}, {1, QColor("#1861d2")}};
inline const QGradientStops LogoRight{{0, QColor("#35d3f7")}, {1, QColor("#0084fd")}};
inline const QGradientStops LogoBase{{0, QColor("#2bcef6")}, {1, QColor("#027cff")}};
} // namespace Brand

namespace CameraDevice
{
inline const QGradientStops Side{{0, QColor("#29475c")}, {1, QColor("#112333")}};
inline const QColor SideBorder("#4d9dc9");
inline const PanelStyle Body{QColor("#355165"), QColor("#101c27"), QColor("#60b5e8"), 20};
inline const PanelStyle Face{QColor("#1c3040"), QColor("#0a151f"), QColor("#4a6578"), 14};
inline const QColor ScrewBorder("#657887");
inline const QColor ScrewFill("#141f29");
inline const QGradientStops Rim{
    {0, QColor("#7797aa")}, {.35, QColor("#263e50")}, {.8, QColor("#030a0f")}, {1, QColor("#657e8e")}};
inline const QColor RimBorder("#5283a3");
inline const QColor InnerRim("#060d15");
inline const QColor InnerRimBorder("#344f65");
inline const QGradientStops Glass{{0, QColor("#147ac7")}, {.45, QColor("#0a315c")}, {1, QColor("#020913")}};
inline const QColor GlassBorder("#1b3b55");
inline const QColor Aperture("#030c18");
inline const QColor Reflection(83, 174, 233, 110);
} // namespace CameraDevice

namespace Laptop
{
inline const PanelStyle Frame{QColor("#d2e1eb"), QColor("#667c91"), QColor("#d2e5f2"), 9};
inline const PanelStyle Screen{QColor("#111e2b"), QColor("#050b10"), QColor("#405467"), 4};
inline const QColor Base("#8298aa");
inline const QColor BaseBorder("#cfdfeb");
inline const QColor Keyboard("#233444");
inline const QColor Touchpad("#bad0de");
} // namespace Laptop
} // namespace Theme
} // namespace Ui
