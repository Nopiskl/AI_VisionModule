# V851S Camera Application

`Application` 是板端 Camera 产品程序的权威源码树：一套顶层 CMake 生成 Qt GUI、
单一 MPP 服务和独立 YOLO worker。Tina/OpenWrt 只作为工具链、BSP、rootfs 和薄
package adapter，不维护第二份业务源码。

## 当前目标

| CMake target | 产物 | 职责 |
| --- | --- | --- |
| `camera_gui` | `camera-gui` | 800×480 Qt Widgets、后端监督和 Home/Camera/Album/UVC/OpenCV 入口 |
| `camera_mpp_service` | `camera-mpp-service` | 唯一 MPP owner；Camera/可选 RTSP/Playback/UVC Out |
| `camera_yolov8_opencv` | `camera-yolo-worker` | OpenCV/V4L2 + VIPLite YOLO worker；互斥接管 camera/fb |

`APPLICATION_BUILD_MPP_EXAMPLES=ON` 还会构建 sample 派生的 Preview、RTSP 和
Recording reference。它们只用于迁移/调用顺序参考，不是产品服务。

当前实现、已确认事实和阻塞项以 [`docs/STATUS.md`](docs/STATUS.md) 为准。源码存在不
表示已交叉编译或板测；产品边界见
[`docs/architecture/README.md`](docs/architecture/README.md)，
文档入口和事实归属见 [`docs/README.md`](docs/README.md)，MPP/MPI 开发入口见
[`docs/platform/mpp/`](docs/platform/mpp/)，组件设计入口见
[`docs/components/`](docs/components/)。后续 Agent 先阅读
[`agent.md`](agent.md)。

把源码 handoff 带到交叉编译环境或 V851S 目标板时，按
[`实际环境构建与首次运行`](docs/deployment-bringup.md) 补齐工具链、目标 Qt/OpenCV、
本地 MPP bundle、模型和 rootfs 依赖，并按顺序保留构建与板端证据。

## 准备参考树和 standalone MPP bundle

在工作区根目录准备固定提交的只读参考树：

```sh
./Application/tools/prepare_references.sh
```

在 Application 目录准备被 Git 忽略的最小 link-time bundle：

```sh
cd Application
./tools/fetch_sunxi_mpp.sh
./tools/audit_sunxi_mpp.sh
```

已有 `TMP/Yuzukilizard` 时可避免重新克隆：

```sh
SUNXI_MPP_SOURCE_CHECKOUT="$PWD/../TMP/Yuzukilizard" \
  ./tools/fetch_sunxi_mpp.sh
```

参考树不参与构建；bundle 由 `third_party/sunxi-mpp.manifest` 选择头文件/库并记录
固定提交与 SHA-256。外部 MPP/VIPLite 二进制授权未确认前，不提交或重新分发生成
bundle。静态审核范围和限制见
[`MPP 迁移参考工具`](docs/components/mpp-reference-tools/README.md)。

## 交叉配置

工具链、musl sysroot 和路径必须显式提供：

```sh
cmake -S Application -B build/v851s \
  -DCMAKE_TOOLCHAIN_FILE="$PWD/Application/cmake/toolchains/v851s-musl.cmake" \
  -DV851S_C_COMPILER=/opt/v851s/bin/arm-openwrt-linux-gcc \
  -DV851S_CXX_COMPILER=/opt/v851s/bin/arm-openwrt-linux-g++ \
  -DV851S_SYSROOT=/opt/v851s/sysroot \
  -DAPPLICATION_BUILD_MPP=ON \
  -DAPPLICATION_BUILD_GUI=ON

cmake --build build/v851s
```

启用 YOLO 时还需要目标 OpenCV，并追加：

```text
-DOpenCV_DIR=/opt/v851s/sysroot/usr/lib/cmake/opencv4
-DAPPLICATION_BUILD_YOLOV8=ON
```

这些命令只是交叉构建入口，不表示当前已经执行成功。实际执行后应记录
commit/worktree、工具链、sysroot、Qt/MPP manifest 和完整日志；如果结果改变当前能力
或 blocker，再更新 `docs/STATUS.md`。

## 运行和配置

MPP 服务：

```sh
/usr/bin/camera-mpp-service \
  --config /etc/v851s-camera/mpp-service.conf
```

GUI：

```sh
/usr/bin/camera-gui \
  --service /usr/bin/camera-mpp-service \
  --service-config /etc/v851s-camera/mpp-service.conf \
  --yolo /usr/libexec/v851s-camera/camera-yolo-worker \
  --yolo-model /etc/v851s-camera/yolov8.nb \
  --yolo-classes /etc/v851s-camera/yolov8-classes.txt
```

`camera-gui` 的外层进程不打开 framebuffer；它启动 Qt UI 子进程。首页 OpenCV 入口
选择 YOLO 后，UI
先停止 MPP 并退出以释放 linuxfb，再启动 worker 直接输出 framebuffer。worker 退出后
自动重建 Qt/MPP；YOLO 运行期间可向外层监督器发送 `SIGUSR1` 请求返回 Qt。模型和类别
文件属于部署输入，仓库不会自动安装未提供的模型。

GUI 当前固定为 800×480。Camera 使用透明 Qt overlay；相册照片由 Qt 显示，视频由 MPP
在局部 VO 矩形显示。页面接线、状态真值和后续修改约束见
[`GUI 集成文档`](docs/components/camera-gui/ui-integration.md)。目标 rootfs 还需提供可用的
中文字体（主题首选 Noto Sans CJK SC）和 Qt JPEG imageformat plugin。

机器可读默认值在 [`configs/mpp-service.conf`](configs/mpp-service.conf)，参数语义在
[`camera-mpp-service 配置`](docs/components/camera-mpp-service/configuration.md)，IPC 线格式在
[`docs/interfaces/ipc-v1.md`](docs/interfaces/ipc-v1.md)。

UVC 模式把板卡作为 USB Device 使用：服务只打开系统已配置并绑定好的 gadget
`VIDEO_OUTPUT` 节点，Host STREAMON 后才创建 ISP/VI/VENC 路径。USB configfs gadget 的
创建、UDC 绑定以及与 ADB composite function 的兼容属于部署范围，本阶段不由产品服务
修改。协议和 sample 映射见 [`UVC 平台文档`](docs/platform/mpp/uvc.md)。

## 目标运行环境边界

standalone 构建仍依赖与导入 archive 兼容的目标环境：32-bit ARMv7 hard-float、
musl/libstdc++/libgcc、V851S MPP/ION/VIN/ISP/DISP/VENC/VDEC 驱动接口、sensor DTS/
firmware/ISP tuning，以及 manifest 选择的运行库。`APPLICATION_INSTALL_VENDOR_RUNTIME`
只安装启用目标需要的 vendor runtime；rootfs 已提供 ABI 兼容版本时应关闭，避免
静默替换系统库。
