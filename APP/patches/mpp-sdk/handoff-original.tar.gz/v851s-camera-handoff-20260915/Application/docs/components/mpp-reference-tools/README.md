# MPP 迁移参考工具

本页说明 `Application/src/component/MPP/` 下从 sample 提取的可选参考目标。它们用于
依赖验证、MPI 生命周期核对和迁移实验，不是产品运行时组件，也不能组合成产品功能。

源码入口：[`../../../src/component/MPP/`](../../../src/component/MPP/)。

## 参考目标

| 源码目录 | 构建目标/产物 | 参考用途 |
| --- | --- | --- |
| `preview/` | `camera-mpp-preview` | VI/ISP 到 VO 的最小预览路径 |
| `rtsp/` | `camera-mpp-rtsp` | VI/VENC 与 RTSP sink 的迁移参考 |
| `preview+encoder/` | `camera-mpp-recording-reference` | VI/VENC/MUX 录像路径参考 |

这些目标仅在显式启用 `APPLICATION_BUILD_MPP_EXAMPLES` 时参与构建。它们可以保留随
sample 带来的原始 `Readme.txt`，但原始说明中的设备节点、参数、网络地址和资源数量
都不是产品默认值或 V851S 能力证明。

## 与产品 Service 的边界

- 产品唯一 MPP owner 是 `camera-mpp-service`；它的实际设计见
  [`../camera-mpp-service/`](../camera-mpp-service/)。
- 不允许同时启动多个参考目标占用同一 sensor，也不允许用多个参考进程实现
  Preview + Record + RTSP。
- 从参考目标提取到产品代码时，必须重新建立配置校验、资源账本、幂等 stop、失败
  rollback、有界队列和 Get/Release 配对。
- MPP/MPI 接口优先读取 [`../../platform/mpp/`](../../platform/mpp/) 并核对实际
  sysroot；sample 的外部来源、固定版本和适用边界见
  [`../../platform/reference-sources.md`](../../platform/reference-sources.md)。

## Standalone bundle 边界

`tools/fetch_sunxi_mpp.sh` 按 `third_party/sunxi-mpp.manifest` 从固定的
Yuzukilizard checkout 生成本地 bundle，不把上游完整预编译目录复制进产品源码。
`tools/audit_sunxi_mpp.sh` 曾确认所选对象和共享库为 32-bit ARM、VFP register
arguments（hard-float），保留必要 SONAME 链，并能找到当前 Service 引用的
`AW_MPI_*`、TinyServer 创建和视频 append 符号。

上述结论只证明固定输入的静态属性，仍有以下边界：

- 预编译库绑定特定 ARM/musl/hard-float BSP，目标工具链、sysroot 和 rootfs 必须匹配；
- 符号存在不能证明全部 static archive 的最终链接闭包；
- 上游 `Software/sunxi-mpp` 没有覆盖重新发布的明确许可，VIPLite 还含专有声明；
- 生成 bundle 在授权和发布来源确认前不得提交或重新分发；
- sample 或参考目标的源码存在、静态检查通过都不代表 V851S 已经能够运行。

外部来源、固定 commit、准备方法和更详细的许可/ABI 说明见
[`reference-sources.md`](../../platform/reference-sources.md)。组件集成风险见
[`camera-mpp-service/known-limitations.md`](../camera-mpp-service/known-limitations.md)，
当前能力只看 [`STATUS.md`](../../STATUS.md)。
