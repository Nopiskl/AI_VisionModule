# Application 当前状态

- 文档角色：当前实现、已经确认的事实、能力声明和活动阻塞的唯一状态面板
- 最近复核：2026-09-15
- 代码基线：仓库 `c5beacf` 上的未提交工作树；`Application` 整体尚未纳入 Git 跟踪
- 产品范围与 Decision：[`requirements.md`](requirements.md)
- 后续顺序与出口：[`roadmap.md`](roadmap.md)

本页只回答“现在做到哪里、已经实际确认什么、还卡在哪里”。它不重新定义 requirement、
架构、配置默认值或测试方法。

## 1. 状态字段

| 字段 | 允许值/写法 | 含义 |
| --- | --- | --- |
| Implementation | `Not started / Partial / Implemented` | 当前源码是否存在并形成目标路径 |
| Capability | `Candidate / Board confirmed / Product accepted` | 对外可承诺程度 |
| Confirmed | 直接写实际执行过的检查或观察 | 不使用计划、模板、sample 或文件名冒充结果 |
| Next condition | 下一项需要满足的可观察条件 | 不规定验证命令；由主维护者在任务中指定 |

项目不使用统一验证等级。必须明确区分静态源码检查、真实构建、目标板观察和最终验收；
后一项不能由前一项自动推出。

## 2. 执行摘要

统一 CMake、800×480 Qt GUI、版本化 IPC 和单一 MPP Service 已有产品源码。用户提供的
新 Home/Camera/Album/UVC 视觉源码已迁入产品 GUI，并接通 Camera 控制、RTSP 地址、
有界相册、局部 VO Playback、UVC 后端状态和首页 OpenCV→YOLO 交接。Camera Preview、
Snapshot、Record、可选 RTSP、视频 Playback、UVC Out 和 GUI 控制路径完成过源码与依赖静态检查，
但尚无可复现的 ARM/musl 交叉构建、最终链接/打包或 V851S 目标板结果。因此所有活动
媒体、USB 输出、显示和综合能力仍是 `Candidate`，没有 `Board confirmed` 或
`Product accepted` 声明。

YOLO 产品入口、Qt→YOLO→Qt 会话监督、MPP/YOLO shared backend lock，以及 Qt 启动
MPP 前的 linuxfb/DISP2 layer-handle 门禁已经形成源码闭环。按当前任务边界未执行实机
验证；本地环境也没有 Qt/OpenCV 开发包，因此这次实现不提升 Capability。

录像期间 Snapshot 已由产品决定为不允许：服务端保持最终拒绝门禁；后端用单调时钟
发布 `record_elapsed_ms`。Qt 在后端确认 Recording 后锁定 Camera 页面，只显示顶部已录
时长和 iOS 风格停止按钮，离开 Recording 后恢复普通控件。

## 3. 交付基础

| 项目 | Requirement IDs | Implementation | Confirmed | Next condition |
| --- | --- | --- | --- | --- |
| Application Git 基线 | BUILD-001 | Partial | 当前工作树可以读取，但大部分内容未被 Git 跟踪 | 审核既有删除/新增内容并形成明确 commit |
| 统一顶层 CMake/多进程 | ARCH-001～003、BUILD-001/002 | Implemented | host CMake 的 MPP-only 配置成功，manifest 空格解析问题已修正；`camera_common` 实际编译成功 | 使用指定 ARM/musl 工具链完成可重复配置、构建、安装和打包 |
| `camera-mpp-service` 骨架与 IPC | ARCH-004、MPP-001/002 | Implemented | Camera/Playback/UVC 资源 owner、MPI 符号和源码生命周期完成静态检查 | 目标链接、启动、IPC handshake 和幂等停止得到实际确认 |
| standalone bundle/发布边界 | BUILD-003 | Partial | manifest、SHA-256、ARM hard-float ABI、SONAME 和产品引用符号完成静态检查 | 确认 rootfs 来源、再分发许可和最终链接闭包 |

静态依赖边界见 [`mpp-reference-tools`](components/mpp-reference-tools/)，Service 生命周期和
风险见 [`camera-mpp-service`](components/camera-mpp-service/)。

## 4. 产品能力

| 能力 | Requirement IDs | Implementation | Capability | Confirmed / 尚未确认 |
| --- | --- | --- | --- | --- |
| Camera Preview | CAM-001 | Implemented | Candidate | 源码生命周期已检查；尚未确认目标板画面、启停和资源回收 |
| Snapshot | CAM-002、CAM-009 | Implemented | Candidate | frame/stream 配对及录像中服务端拒绝已静态检查；尚未确认 JPEG 和 Preview 连续性 |
| Record | CAM-003～005、CAM-007～009、GUI-008 | Implemented | Candidate | VI/VENC/MUX、安全提交、后端单调计时和专用录像态 GUI 已形成源码；尚未确认实际文件、交互、满盘、拔卡和断电行为 |
| 可选 RTSP | CAM-006 | Implemented | Candidate | H.264 SPS/PPS→SDP header、三段 bounded copy→Release→sink、新客户端 IDR 门禁和异常回收已静态检查；尚未确认目标链接、纯视频 SDP、重连和 Record 并发 |
| 视频 Playback/相册 | PLAY-001～007 | Implemented | Candidate | DEMUX/VDEC/CLOCK/单一 VO layer、局部 fitted rectangle 回传、GUI 有界媒体目录与照片/视频分流已形成源码；没有 Qt 目标构建、媒体组合和 Pause/Resume 的目标板结果 |
| UVC Out | GUI-004/005、UVC-000～004 | Implemented | Candidate | `sample_uvcout` 格式矩阵、PROBE/COMMIT、CONNECT/DISCONNECT、STREAMON/OFF、gadget mmap、有界复制、VI/VENC Get/Release、逆序回滚和以后端为真值的 GUI 状态已形成源码；没有 gadget/Host/目标板结果，ADB composite 明确未纳入 |
| Qt GUI/进程监督 | GUI-001～008、YOLO-003 | Implemented | Candidate | 800×480 Home/Camera/Album/UVC 页面、RTSP 实际 URL、录像态唯一停止按钮/后端计时、媒体目录模型、Qt 子进程、外层会话监督和 OpenCV/YOLO 入口已形成源码路径；本机缺 Qt5 development package，尚无目标 Qt 构建和进程切换结果 |
| Qt/DISP2 透明叠加 | DISP-001～008、OWN-002、OPEN-012 | Implemented | Candidate | adapter 已读取配置并用 framebuffer ioctl 门禁 UI/video handle 与 lock；Camera 全画布、Playback 配置子矩形、实际 fitted rect IPC 回传和 Qt 局部清 alpha 已形成源码，实际 ioctl、透明和层级未确认 |
| YOLO worker 产品综合 | YOLO-001～003、OWN-001～003 | Implemented | Candidate | worker 已接入 shared lock、显式 tensor 契约、VIPLite 失败回收、可配置 V4L2/fb 和 stride-aware mmap RGB565 输出；没有 OpenCV/VIPLite 目标构建或运行结果 |

## 5. 综合与发布

| 项目 | Requirement 范围 | Implementation | Capability | Next condition |
| --- | --- | --- | --- | --- |
| MPP/YOLO owner 双向切换 | YOLO-002/003、OWN-001～003 | Implemented | Candidate | Camera/Playback/UVC 均由同一 MPP 服务持有；shutdown→MPP exit→Qt 析构→YOLO→Qt 重建、共享 flock 和 parent-death 路径已实现；尚无目标进程/设备观察 |
| 当前产品综合验收 | 全部当前 Accepted requirements | Not started | Candidate | 单能力、综合切换、长稳、故障、许可和发布条件全部满足 |

## 6. Decision blockers

| Open | 当前影响 | Decision owner |
| --- | --- | --- |
| OPEN-012 | Qt/MPP layer 映射、透明合成和显示验收按主维护者决定保留到实机验证阶段 | [`requirements.md`](requirements.md) |

## 7. Delivery blockers

| ID | 活动阻塞 | 解除条件 |
| --- | --- | --- |
| BLK-001 | Application 未形成 Git 基线 | 审核当前工作树并将产品框架纳入明确 commit |
| BLK-002 | standalone MPP/VIPLite 发布授权与最终 rootfs 来源未确认 | 完成许可和发布来源决定 |
| BLK-003 | RTSP 纯视频 SDP、断连和重连未确认 | 完成最终链接及目标板 SDP/客户端循环检查 |
| BLK-004 | 可移动存储断电一致性未确认 | 在目标文件系统确认 `.part`、repair metadata、目录同步和恢复工具 |
| BLK-005 | UVC gadget node、Host 协商/取流和断连重连未确认 | 使用匹配固定格式索引的系统 descriptor，在目标板逐格式完成 Host 循环检查；ADB composite 另行评审 |

## 8. 已确认边界

`tools/audit_sunxi_mpp.sh` 于 2026-09-15 在固定 Yuzukilizard commit
`94bb93ad67fd862c5f6fe6c29fbc0f54950e7107` 和当前本地未提交工作树上通过，覆盖 manifest、
SHA-256、ARM hard-float 属性、共享库 ABI、产品引用的 `AW_MPI_*` 符号、TinyServer
header/append/new-client callback 接口、UVC event/control/buffer/Get-Release 路径、800×480
及 Playback 子矩形配置、GUI 相册/RTSP/OpenCV 接线路径、DISP2/YOLO 会话门禁和部分所有权
约束。
本地 host CMake 已成功完成 MPP-only 配置并实际构建 `camera_common`；
`camera-mpp-service` 的全部 C++ 编译单元也已通过编译，最终链接按预期因 bundle 是
ARM ELF 而 host 为 x86_64 停止。
shared backend lock 的 host smoke test 已确认首次非阻塞获取成功、第二 owner 返回
`backend_busy`，首个 owner 释放后第二 owner 可以获取。
`NeuralNetworkRuntime.cpp` 使用 bundle VIPLite 头文件通过 host 语法编译。2026-09-15
新增的 ServiceConfig、Playback fitted rectangle、录像单调计时和 IPC 字段通过 host C++
编译；更新后的静态审核确认录像中 Snapshot 拒绝、录像态唯一停止控件和计时接线；
当前 `mpp-service.conf` 也通过实际 `ServiceConfig::load()`，得到
`800×480; playback=144,40,644,388`；
本机 GUI 配置再次因没有 Qt 5.12 development package 停止，YOLO 配置因没有 OpenCV development
package 停止；不把这些结果解释为 ARM 目标构建、最终链接或板端能力。

尚未确认的共同范围包括：

- ARM/musl 交叉配置、编译和最终链接；
- install、bundle/rootfs/package 闭环和再分发许可；
- sensor、ISP、codec、DISP2、USB gadget、存储和网络的目标板行为；
- Camera 子能力并发、Camera/Playback/UVC/YOLO 切换、长稳、内存、温度和故障恢复。
- 800×480 新 GUI 的触摸命中、中文字体/JPEG plugin、Camera 全画布透明和 Album 局部透明
  合成。

## 9. 更新规则

| 变化 | 更新内容 |
| --- | --- |
| 源码新增、移除或形成闭环 | 更新 Implementation；不自动提升 Capability |
| 用户指定检查产生新事实 | 在 Confirmed 中摘要写清基线和范围；原始日志不堆入本页 |
| 目标板确认单项能力 | 仅对应能力可升为 Board confirmed，不外推其他组合 |
| 综合验收和发布条件完成 | 对应范围才可升为 Product accepted |
| requirement/Open Decision 变化 | 先更新 requirements，再同步 ID 和 blocker 引用 |
| 新增或解除执行阻塞 | 更新 Delivery blockers 和 Next condition |

每次更新本页必须同步最近复核日期和代码基线。
