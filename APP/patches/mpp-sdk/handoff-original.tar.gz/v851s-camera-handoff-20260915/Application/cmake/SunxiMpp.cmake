include_guard(GLOBAL)

include(CMakeParseArguments)
find_package(Threads REQUIRED)

function(_sunxi_mpp_collect_manifest manifest root)
    if(NOT EXISTS "${manifest}")
        message(FATAL_ERROR "sunxi-mpp manifest does not exist: ${manifest}")
    endif()

    file(STRINGS "${manifest}" manifest_lines)
    foreach(line IN LISTS manifest_lines)
        string(STRIP "${line}" line)
        if(line STREQUAL "" OR line MATCHES "^#")
            continue()
        endif()

        # The manifest is deliberately space-delimited. CMake's regular
        # expression dialect does not treat \t as a tab escape here; using it
        # inside the character class would also exclude the literal letter
        # "t" from paths such as lib/libmedia_utils.a.
        if(NOT line MATCHES "^([a-z0-9_]+) +([^ ]+)$")
            message(FATAL_ERROR "Malformed sunxi-mpp manifest line: ${line}")
        endif()

        string(TOUPPER "${CMAKE_MATCH_1}" group)
        set(relative_path "${CMAKE_MATCH_2}")
        set(absolute_path "${root}/${relative_path}")
        if(NOT EXISTS "${absolute_path}")
            message(FATAL_ERROR
                "Required sunxi-mpp artifact is missing: ${absolute_path}\n"
                "Run Application/tools/fetch_sunxi_mpp.sh first, or set "
                "SUNXI_MPP_ROOT to a prepared bundle.")
        endif()
        list(APPEND "SUNXI_MPP_${group}_FILES" "${absolute_path}")
    endforeach()

    foreach(group
            CORE VI VO VENC MUXER RTSP DEMUX VDEC
            RUNTIME_LINK RUNTIME_DATA NPU RECORD_SAMPLE)
        set("SUNXI_MPP_${group}_FILES"
            "${SUNXI_MPP_${group}_FILES}" PARENT_SCOPE)
    endforeach()
endfunction()

function(_sunxi_mpp_add_profile profile)
    set(options)
    set(one_value_args)
    set(multi_value_args GROUPS)
    cmake_parse_arguments(PROFILE
        "${options}" "${one_value_args}" "${multi_value_args}" ${ARGN})

    set(archives)
    foreach(group IN LISTS PROFILE_GROUPS)
        string(TOUPPER "${group}" group_upper)
        list(APPEND archives ${SUNXI_MPP_${group_upper}_FILES})
    endforeach()

    add_library("sunxi_mpp_${profile}" INTERFACE)
    add_library("sunxi_mpp::${profile}" ALIAS "sunxi_mpp_${profile}")
    target_link_libraries("sunxi_mpp_${profile}" INTERFACE
        sunxi_mpp::headers
        "-Wl,--start-group"
        ${archives}
        "-Wl,--end-group"
        ${SUNXI_MPP_RUNTIME_LINK_FILES}
        Threads::Threads
        ${CMAKE_DL_LIBS}
        rt
        m
        stdc++
    )
endfunction()

function(sunxi_mpp_import)
    set(options)
    set(one_value_args ROOT MANIFEST)
    set(multi_value_args)
    cmake_parse_arguments(MPP
        "${options}" "${one_value_args}" "${multi_value_args}" ${ARGN})

    if(NOT MPP_ROOT)
        message(FATAL_ERROR "sunxi_mpp_import requires ROOT")
    endif()
    if(NOT MPP_MANIFEST)
        message(FATAL_ERROR "sunxi_mpp_import requires MANIFEST")
    endif()
    if(NOT IS_DIRECTORY "${MPP_ROOT}/include" OR
       NOT IS_DIRECTORY "${MPP_ROOT}/lib")
        message(FATAL_ERROR
            "Standalone sunxi-mpp bundle not found at ${MPP_ROOT}.\n"
            "Run Application/tools/fetch_sunxi_mpp.sh first.")
    endif()

    _sunxi_mpp_collect_manifest("${MPP_MANIFEST}" "${MPP_ROOT}")

    file(GLOB_RECURSE sunxi_mpp_include_entries
        CONFIGURE_DEPENDS
        LIST_DIRECTORIES true
        "${MPP_ROOT}/include/*")
    set(sunxi_mpp_include_dirs "${MPP_ROOT}/include")
    foreach(entry IN LISTS sunxi_mpp_include_entries)
        if(IS_DIRECTORY "${entry}")
            list(APPEND sunxi_mpp_include_dirs "${entry}")
        else()
            get_filename_component(entry_dir "${entry}" DIRECTORY)
            list(APPEND sunxi_mpp_include_dirs "${entry_dir}")
        endif()
    endforeach()
    list(REMOVE_DUPLICATES sunxi_mpp_include_dirs)

    add_library(sunxi_mpp_headers INTERFACE)
    add_library(sunxi_mpp::headers ALIAS sunxi_mpp_headers)
    target_include_directories(sunxi_mpp_headers SYSTEM INTERFACE
        ${sunxi_mpp_include_dirs})

    _sunxi_mpp_add_profile(preview GROUPS CORE VI VO)
    _sunxi_mpp_add_profile(streaming GROUPS CORE VI VENC RTSP)
    _sunxi_mpp_add_profile(recording GROUPS CORE VI VENC MUXER)
    _sunxi_mpp_add_profile(preview_recording GROUPS CORE VI VO VENC MUXER)
    _sunxi_mpp_add_profile(service
        GROUPS CORE VI VO VENC MUXER RTSP DEMUX VDEC)

    add_library(sunxi_mpp_npu INTERFACE)
    add_library(sunxi_mpp::npu ALIAS sunxi_mpp_npu)
    target_link_libraries(sunxi_mpp_npu INTERFACE
        sunxi_mpp::headers
        ${SUNXI_MPP_NPU_FILES}
        ${CMAKE_DL_LIBS}
    )

    set(SUNXI_MPP_IMPORTED_ROOT "${MPP_ROOT}" CACHE INTERNAL
        "Imported standalone sunxi-mpp root")
    set(SUNXI_MPP_IMPORTED_RUNTIME_FILES
        "${SUNXI_MPP_RUNTIME_LINK_FILES};${SUNXI_MPP_RUNTIME_DATA_FILES}"
        CACHE INTERNAL "Imported standalone sunxi-mpp runtime libraries")
    set(SUNXI_MPP_IMPORTED_NPU_FILES "${SUNXI_MPP_NPU_FILES}"
        CACHE INTERNAL "Imported standalone VIPLite runtime libraries")
endfunction()

function(sunxi_mpp_install_runtime)
    if(NOT SUNXI_MPP_IMPORTED_ROOT)
        message(FATAL_ERROR "sunxi_mpp_import must run before installation")
    endif()

    if(APPLICATION_BUILD_MPP OR APPLICATION_BUILD_MPP_EXAMPLES)
        # Preserve the upstream symlink chain and SONAME-compatible aliases.
        install(DIRECTORY "${SUNXI_MPP_IMPORTED_ROOT}/lib/"
            DESTINATION "${CMAKE_INSTALL_LIBDIR}"
            USE_SOURCE_PERMISSIONS
            FILES_MATCHING
            PATTERN "libglog.so*"
            PATTERN "libunwind.so*"
            PATTERN "libasound.so*"
        )
    endif()
    if(APPLICATION_BUILD_YOLOV8)
        install(FILES ${SUNXI_MPP_IMPORTED_NPU_FILES}
            DESTINATION "${CMAKE_INSTALL_LIBDIR}")
    endif()
endfunction()
